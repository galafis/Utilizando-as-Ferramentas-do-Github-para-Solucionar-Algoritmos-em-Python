def inverter_string(texto):
    return texto[::-1]

print(inverter_string("Gabriel"))
