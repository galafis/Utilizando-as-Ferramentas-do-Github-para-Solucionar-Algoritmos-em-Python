def soma(a, b):
    return a + b

print(soma(3, 5))
